
package datastructure;
     
public class DataStructure {

    public static void main(String[] args) {
        InterfacePilha sistema = new InterfacePilha();
        sistema.setVisible(true);
    }
    
}
