package datastructure;

public class Palete {
}
